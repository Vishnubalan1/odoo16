# -*- coding: utf-8 -*-

from odoo import fields, models

class CoC(models.Model):
    _name = 'clash.codes'
    """coc model"""

    name = fields.Many2one('res.partner','name')


