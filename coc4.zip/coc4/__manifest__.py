{
    'name': "clash of codes",
    'version': '16.1.0.0',
    'depends': ['base',],
    'author': "vishnu",
    'application': True,
    'description': """clash of codes4""",
    'data': [
    ]

}